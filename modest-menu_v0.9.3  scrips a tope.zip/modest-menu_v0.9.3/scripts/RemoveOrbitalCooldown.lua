menu.add_action("Remove orbital Cooldown", function()    
        globals.set_int(262145 + 22852, 0)
    end)